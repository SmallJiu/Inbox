package cat.jiu.core.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.commons.io.FileExistsException;

import javax.annotation.Nullable;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class HttpFile {

    // Test
    public static void main(String[] args) {
        new HttpFile()
                .setSaveFile(new File("C:/test.json"))
                .addUrls(
                        "https://v.api.aa1.cn/api/api-mima/mima.php?msg=10",
                        "https://v.api.aa1.cn/api/api-mima/mima.php?msg=20",
                        "https://v.api.aa1.cn/api/api-mima/mima.php?msg=30",
                        "https://v.api.aa1.cn/api/api-mima/mima.php?msg=40"
                )
                .tryDownload((fileCurrentLength, fileTotalLength, progress) ->
                    System.out.println("Downloading...  " + progress + " (" + fileCurrentLength + " / " + fileTotalLength + ")")
                , file -> {
                    try {
                        JsonObject object = JsonParser.parseReader(new FileReader(file)).getAsJsonObject();
                        System.out.println(object);
                        System.out.println(object.get("responseText").getAsString().replace("\n", "").replace("<br>", ""));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }, ()->
                    System.err.println("Downloading fail !")
                );
    }


    private File saveFile;
    private List<String> urls;
    protected boolean overwrite;

    public HttpFile() {
    }

    public HttpFile(File saveFile, String... urls) {
        this.setSaveFile(saveFile);
        this.addUrls(urls);
    }

    public File getSaveFile() {
        return saveFile;
    }

    public HttpFile setSaveFile(File saveFile) {
        this.saveFile = saveFile;
        return this;
    }

    public List<String> getUrls() {
        return urls;
    }

    public HttpFile addUrls(String... urls) {
        if (this.urls == null) {
            this.urls = new ArrayList<>(Arrays.asList(urls));
        }else {
            this.urls.addAll(Arrays.asList(urls));
        }
        return this;
    }
    public HttpFile setUrls(String... urls) {
        this.urls = new ArrayList<>(Arrays.asList(urls));
        return this;
    }
    public HttpFile setUrls(List<String> urls) {
        this.urls = urls;
        return this;
    }

    public boolean isOverwrite() {
        return overwrite;
    }

    public HttpFile setOverwrite(boolean overwrite) {
        this.overwrite = overwrite;
        return this;
    }

    public void tryDownload(@Nullable IProgress progress, @Nullable Consumer<File> done, @Nullable Runnable fail) {
        new Thread(()->{
            List<String> urls = this.getUrls();
            boolean downloaded = false;
            if (urls != null && !urls.isEmpty()) {
                for (String url : urls) {
                    try {
                        try {
                            download(url, this.getSaveFile(), this.isOverwrite(), progress);
                        }catch (FileExistsException ignored) {}
                        if(done != null) done.accept(this.getSaveFile());
                        downloaded = true;
                        break;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            if (!downloaded && fail != null) {
                fail.run();
            }
        }).start();
    }

    public static void download(String url, File savePath, boolean overwrite, IProgress call) throws IOException {
        if(savePath.exists() && !overwrite) throw new FileExistsException(savePath);
        if(savePath.getParentFile() != null && !savePath.getParentFile().exists()) {
            savePath.getParentFile().mkdirs();
        }
        if (!savePath.exists()) {
            savePath.createNewFile();
        }

        try(Auto conn = new Auto(new URL(url).openConnection()).connect();
            InputStream net = conn.connection.getInputStream();
            OutputStream localOut = new FileOutputStream(savePath)) {

            final long fileTotalLength = conn.connection.getContentLengthLong();
            long currentLength = 0;

            byte[] buf = new byte[8192];
            int read;

            while((read = net.read(buf)) != -1) {
                localOut.write(buf, 0, read);

                if (call != null) {
                    currentLength += read;
                    double progress = Math.ceil((double)currentLength / fileTotalLength) * 100;
                    call.call(currentLength, fileTotalLength, Double.parseDouble(String.format("%.3f", progress)));
                }
            }
        }
    }

    public interface IProgress {
        void call(long fileCurrentLength, long fileTotalLength, double progress);
    }

    private static class Auto implements AutoCloseable {
        private final URLConnection connection;
        public Auto(URLConnection connection) {
            this.connection = connection;
        }
        public Auto connect() throws IOException {
            if(this.connection!=null) {
                this.connection.connect();
            }
            return this;
        }
        @Override
        public void close() throws IOException {
            if(this.connection instanceof HttpURLConnection) {
                ((HttpURLConnection)this.connection).disconnect();
            }
        }
    }
}
