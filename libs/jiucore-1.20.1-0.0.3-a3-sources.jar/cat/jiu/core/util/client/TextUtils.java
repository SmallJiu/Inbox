package cat.jiu.core.util.client;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.*;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

public class TextUtils {

    public static MutableComponent copyOnClickedText(Component component) {
        return copyOnClickedText(component, component.getString());
    }
    public static MutableComponent copyOnClickedText(Component component, String copy) {
        return ComponentUtils.wrapInSquareBrackets(((MutableComponent)component).withStyle((style) ->
            style.withColor(ChatFormatting.GREEN).withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, copy)).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommonComponents.GUI_COPY_LINK_TO_CLIPBOARD)).withInsertion(copy)
        ));
    }

    public static List<FormattedCharSequence> split(String text, int maxLength, boolean useMcWarp) {
        return split(Component.literal(text), maxLength, useMcWarp);
    }

    public static List<FormattedCharSequence> split(Component text, int maxLength, boolean useMcWarp) {
        if (useMcWarp) {
            return RenderUtils.getFontRenderer().split(text, maxLength);
        }else {
            List<FormattedCharSequence> list = new ArrayList<>();
            if (RenderUtils.width(text) <= maxLength) {
                list.add(FormattedCharSequence.forward(text.getString(), Style.EMPTY));
            }else {
                StringBuilder sb = new StringBuilder();
                for (char c : text.getString().toCharArray()) {
                    if (c == '\n') {
                        list.add(FormattedCharSequence.forward(sb.toString(), Style.EMPTY));
                        sb.setLength(0);
                    } else {
                        sb.append(c);
                        if (RenderUtils.width(sb.toString()) >= maxLength) {
                            list.add(FormattedCharSequence.forward(sb.toString(), Style.EMPTY));
                            sb.setLength(0);
                        }
                    }
                }
                if (!sb.isEmpty()) {
                    list.add(FormattedCharSequence.forward(sb.toString(), Style.EMPTY));
                }
            }
            return list;
        }
    }
}
