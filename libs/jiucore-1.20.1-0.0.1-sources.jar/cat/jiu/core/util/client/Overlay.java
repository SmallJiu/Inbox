package cat.jiu.core.util.client;

import cat.jiu.core.api.element.IOverlay;
import cat.jiu.core.util.registry.StaticRegistry;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(Dist.CLIENT)
public class Overlay {
    static final StaticRegistry<String, IOverlay> REGISTRY = new StaticRegistry<>();
    public static <T extends IOverlay> T register(T overlayInstance) {
        REGISTRY.register(overlayInstance);
        return overlayInstance;
    }

    @SubscribeEvent
    public static void onPreOverlayRender(RenderGuiEvent.Pre event) {
        int centerX = Minecraft.getInstance().getWindow().getGuiScaledWidth() / 2;
        int centerY = Minecraft.getInstance().getWindow().getGuiScaledHeight() / 2;
        if (REGISTRY.hasEntry()) {
            for (String id : REGISTRY.getIDs()) {
                IOverlay overlay = REGISTRY.get(id);
                if (overlay.isEnable(IOverlay.EventAction.RENDER_PRE) && overlay.render(event.getGuiGraphics(), event, centerX, centerY)) {
                    if (overlay.canRemove(true)) {
                        REGISTRY.unregister(id);
                    }
                    break;
                }
            }
        }
    }

    @SubscribeEvent
    public static void onPostOverlayRender(RenderGuiEvent.Post  event) {
        int centerX = Minecraft.getInstance().getWindow().getGuiScaledWidth() / 2;
        int centerY = Minecraft.getInstance().getWindow().getGuiScaledHeight() / 2;
        if (REGISTRY.hasEntry()) {
            for (String id : REGISTRY.getIDs()) {
                IOverlay overlay = REGISTRY.get(id);
                if (overlay.isEnable(IOverlay.EventAction.RENDER_POST) && overlay.render(event.getGuiGraphics(), event, centerX, centerY)) {
                    if (overlay.canRemove(false)) {
                        REGISTRY.unregister(id);
                    }
                    break;
                }
            }
        }
    }

    @SubscribeEvent
    public static void onKeyTyped(InputEvent.Key event) {
        if (REGISTRY.hasEntry()) {
            for (String id : REGISTRY.getIDs()) {
                IOverlay overlay = REGISTRY.get(id);
                if (overlay.isEnable(IOverlay.EventAction.KEY_TYPED) && overlay.keyTyped(event.getKey(), event.getScanCode(), event.getAction(), event.getModifiers())){
                    break;
                }
            }
        }
    }
}
