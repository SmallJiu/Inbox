package cat.jiu.core.api.element;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiEvent;

import java.util.function.Supplier;

public interface IOverlay extends Supplier<String> {
    /**
     * @return true if canceled all overlay render.
     */
    @OnlyIn(Dist.CLIENT)
    boolean render(GuiGraphics graphics, RenderGuiEvent event, int windowCenterX, int windowCenterY);

    /**
     * @return true if canceled all overlay response keyTyped.
     */
    default boolean keyTyped(int key, int scanCode, int action, int modifiers) {
        return false;
    }

    /**
     * @return true if this overlay instance is enable on window render.
     */
    boolean isEnable(EventAction event);

    default boolean canRemove(boolean preEvent) {
        return false;
    }

    @Override
    default String get() {
        return this.getClass().getName();
    }

    enum EventAction {
        KEY_TYPED, RENDER_PRE, RENDER_POST;
        public boolean isPreRenderEvent() {
            return this == RENDER_PRE;
        }
        public boolean isPostRenderEvent() {
            return this == RENDER_POST;
        }
        public boolean isKeyTypedEvent() {
            return this == KEY_TYPED;
        }
    }
}
